﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Diagnostics;
using System.IO;
using insta_scrape.Classes;
using insta_scrape.Models;
using System.Text;
namespace insta_scrape.Controllers
{
    public class ScrapeController : Controller
    {
        public ActionResult Scrape()
        {
            return View();
        }
        public ActionResult Main_Scrape()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Main_Scrape(Search_Details sDetails)
        {
            if (!string.IsNullOrEmpty(sDetails.search_term))
            {
                //gaunam visą console outputą vienam stringe
                string scrapeData = RunScrape(sDetails);
                //jį sukapojam į dalis, kad gyvent lengviau būtų
                var data = RipStringApart(scrapeData);
                //Nežinau kodėl šitą pridėjau, bet tarkim
                var specs = data.Item1.ToArray();
                var linkai = data.Item2.ToArray();
               
                //pasetinam ViewBag'o datą, kad galėtume atsivaizduot paveiksliukus
                ViewBag.Specs = specs;
                ViewBag.Links = linkai;
            }
            return View("Main_Scrape");
        }
        private (string[], string[]) RipStringApart(string data)
        {
            int pFrom = data.IndexOf("Query: ") + "Query: ".Length;
            int pTo = data.LastIndexOf("Query close");
            string difQueries = data.Substring(pFrom, pTo - pFrom);

            int sFrom = data.IndexOf("Info Start") + "Info Start".Length;
            int sTo = data.LastIndexOf("Info Close");
            string specs = data.Substring(sFrom, sTo - sFrom);
            string[] specsai= specs.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);

            int lFrom = data.IndexOf("links: ") + "links: ".Length;
            int lTo = data.LastIndexOf("links close");
            string links = data.Substring(lFrom, lTo - lFrom);
            string[] linkai = links.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            //splitinam stringa, kad lengviau butu atsirusiuot visus duomenis ir panaikinam tuscias eilutes

            return (specsai, linkai);
        }

        void proc_DataReceived(object sender, DataReceivedEventArgs e)
        {
            var ss = e.Data;
            // output will be in string e.Data
        
        }

        public string RunScrape(Search_Details sDetails)
        {
            //ProcessStartInfo start = new ProcessStartInfo();

            // pythono exe full path... galim padaryt ir kad pats surastų... nu bet ką čia mes vargstam, o tiem kam reikės naudotis tai gali irgi šiek tiek pavargt xD
            string cmd = "C:\\Users\\apapd\\source\\repos\\insta_scrape\\insta_scrape\\scrape\\google_img.py";
            string args = " \"" + sDetails.search_term + "\" 1";

            // Argumentus suklijuojam
            string combArg = string.Format("{0}{1}", cmd, args);
            var proc = new Process();
            proc.StartInfo.FileName = "C:\\Users\\apapd\\Desktop\\Pythonas\\Python.exe";
            proc.StartInfo.Arguments = combArg;
            // set up output redirection
            proc.StartInfo.StandardOutputEncoding = Encoding.UTF8;
            proc.StartInfo.RedirectStandardOutput = true;
            proc.StartInfo.RedirectStandardError = true;
            proc.EnableRaisingEvents = true;
            proc.StartInfo.UseShellExecute = false;
            proc.StartInfo.CreateNoWindow = true;
            
            // see below for output handler

            using (Process process = Process.Start(proc.StartInfo))
            {
                using (StreamReader reader = process.StandardOutput)
                {
                    // Here are the exceptions from our Python script
                    //string stderr = process.StandardError.ReadToEnd();

                    // Here is the result of StdOut(for example: print "test")
                    string result = reader.ReadToEnd();

                    return result;
                }
            }
        }
    }
}