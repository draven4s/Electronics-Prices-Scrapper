﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace insta_scrape.Classes
{
    public class Search
    {
        public string search_term { get; set; }
        public int search_amount { get; set; }
    }
}
